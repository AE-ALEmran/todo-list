import shutil

shutil.make_archive("Output" ,"zip" )